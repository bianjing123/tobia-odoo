#!/usr/bin/env python3
"""Odoo Connector MCP Server 入口（双模式）。

  native 模式：自研 XML-RPC，覆盖 Odoo 14-20 / Community，16 个工具
  bridge 模式：透传 Odoo 20 Enterprise 官方 /mcp 暴露的工具

用法（通常由 WorkBuddy 自动拉起，无需手动执行）：
    python odoo_mcp_server.py

协议：MCP over stdio（换行分隔的 JSON-RPC 2.0）
依赖：Python 3.9+ 标准库，无需 pip install
"""

from __future__ import annotations

import json
import os
import sys

PLUGIN_ROOT = os.path.dirname(os.path.abspath(__file__))
if PLUGIN_ROOT not in sys.path:
    sys.path.insert(0, PLUGIN_ROOT)

from server.bridge import BridgeError, OdooOfficialMCPClient  # noqa: E402
from server.config import load_config  # noqa: E402
from server.mcp_stdio import MCPStdioServer, log  # noqa: E402
from server.odoo_client import OdooClient  # noqa: E402
from server.tools import TOOLS as NATIVE_TOOLS, _dump, call_tool  # noqa: E402

SERVER_NAME = "odoo-connector"
SERVER_VERSION = "1.2.0"

BRIDGE_STATUS_TOOL = {
    "name": "odoo_bridge_status",
    "description": (
        "查看 Odoo 官方 MCP 桥接状态：端点、会话、协议版本、认证方式、"
        "以及官方暴露的工具数量。桥接模式下用于排查连接问题。"
    ),
    "inputSchema": {"type": "object", "properties": {}},
}


def build_native_server(config):
    client = OdooClient(config)

    def dispatch(name, arguments):
        return call_tool(name, arguments, client, config)

    return MCPStdioServer(SERVER_NAME, SERVER_VERSION, NATIVE_TOOLS, dispatch)


def build_bridge_server(config):
    remote = OdooOfficialMCPClient(config)

    def dispatch(name, arguments):
        if name == "odoo_bridge_status":
            try:
                return _dump(remote.status()), False
            except BridgeError as exc:
                return _dump({"error": exc.message, "detail": exc.detail}), True
        try:
            return remote.call_tool(name, arguments)
        except BridgeError as exc:
            return _dump({"error": exc.message, "detail": exc.detail}), True

    # 启动时拉取官方工具列表；失败则只暴露诊断工具，避免插件完全不可用
    try:
        tools = remote.list_tools()
        log(f"桥接模式：官方 MCP 暴露 {len(tools)} 个工具")
    except BridgeError as exc:
        log(f"桥接模式初始化失败：{exc.message}（仅暴露 odoo_bridge_status）")
        tools = []

    tools = [BRIDGE_STATUS_TOOL] + [
        t for t in tools if t.get("name") != "odoo_bridge_status"
    ]
    return MCPStdioServer(SERVER_NAME, SERVER_VERSION, tools, dispatch)


def main() -> int:
    config = load_config()
    problems = config.validate()

    if config.mode == "bridge":
        server = build_bridge_server(config)
    else:
        server = build_native_server(config)

    if problems:
        log("配置未完整，连接类工具会返回明确错误：" + "；".join(problems))
    return server.run()


if __name__ == "__main__":
    sys.exit(main())
