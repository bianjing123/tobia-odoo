#!/usr/bin/env python3
"""开源仓库自检：结构 / JSON / 敏感信息 / MCP+Skill 入口。零依赖。

用法：python check.py
退出码 0 = 全绿，1 = 有问题。发布或 clone 后都可跑。
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
errors: list[str] = []
warns: list[str] = []
oks: list[str] = []


def check(cond: bool, ok: str, err: str) -> None:
    (oks if cond else errors).append(ok if cond else err)


def warn(msg: str) -> None:
    warns.append(msg)


def load_json(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        errors.append(f"JSON 解析失败 {path.name}: {e}")
        return None


print("=== Odoo Connector 开源仓库自检 ===\n")

# 1. 结构
required = [
    ".codebuddy-plugin/plugin.json",
    ".codebuddy-plugin/marketplace.json",
    ".mcp.json",
    "odoo_mcp_server.py",
    "setup.py",
    "setup.bat",
    "README.md",
    "LICENSE",
    ".gitignore",
    "skills/odoo-connector/SKILL.md",
    "config/odoo.config.example.json",
    "server/odoo_client.py",
    "server/tools.py",
    "server/mcp_stdio.py",
    "server/bridge.py",
    "server/config.py",
]
for rel in required:
    check((ROOT / rel).exists(), f"文件齐全 {rel}", f"缺失 {rel}")

# 2. 清单字段
market = load_json(ROOT / ".codebuddy-plugin" / "marketplace.json")
if market:
    plist = market.get("plugins", [])
    check(len(plist) >= 1 and plist[0].get("name") == "odoo-connector",
          "市场登记 odoo-connector", "marketplace 未登记 odoo-connector")
    check(plist and plist[0].get("source") == "./",
          "source 为 ./（根目录即插件）", "source 不是 ./，clone 后无法直接 add")

plugin = load_json(ROOT / ".codebuddy-plugin" / "plugin.json")
if plugin:
    check(plugin.get("mcpServers") is not None, "plugin 声明 mcpServers", "plugin.json 缺 mcpServers")
    check(plugin.get("skills") is not None, "plugin 声明 skills", "plugin.json 缺 skills")

mcp_cfg = load_json(ROOT / ".mcp.json")
if mcp_cfg:
    srv = mcp_cfg.get("mcpServers", {}).get("odoo-connector", {})
    args = " ".join(str(a) for a in srv.get("args", []))
    check("${CODEBUDDY_PLUGIN_ROOT}" in args,
          "MCP 入口用插件根变量（可移植）",
          "MCP args 未用 ${CODEBUDDY_PLUGIN_ROOT}")
    check(srv.get("command") == "python", "MCP command 为 python", "MCP command 异常")
    env = srv.get("env", {})
    for key in ("ODOO_URL", "ODOO_DB", "ODOO_USER"):
        check(key in env and str(env.get(key, "")) == "",
              f"MCP env {key} 留空（不硬编码）", f"MCP env {key} 非空或缺失")
    for key in ("ODOO_API_KEY", "ODOO_PASSWORD"):
        check(not str(env.get(key, "")), f"{key} 为空", f"{key} 疑似填了真实值！")

# 3. 版本一致
if market and plugin:
    mv = market["plugins"][0].get("version")
    pv = plugin.get("version")
    check(mv == pv, f"版本一致 {pv}", f"版本不一致: market={mv} plugin={pv}")

# 4. Skill frontmatter
skill = ROOT / "skills" / "odoo-connector" / "SKILL.md"
if skill.exists():
    head = skill.read_text(encoding="utf-8")[:600]
    check("name:" in head and "description:" in head,
          "SKILL.md 有 frontmatter", "SKILL.md 缺 frontmatter")

# 5. 敏感信息扫描（排除本脚本）
PATTERNS = [
    (r"leygo", "真实域名 leygo"),
    (r"djsboxs", "真实域名 djsboxs"),
    (r"2669870391", "真实账号"),
    (r"eb5d1fa2", "疑似真实 API Key"),
    (r"\b[a-f0-9]{32}\b", "32 位十六进制串"),
]
texts = [p for p in ROOT.rglob("*")
         if p.is_file() and p.suffix in {".py", ".json", ".md", ".bat", ".txt"}
         and p.resolve() != Path(__file__).resolve()]
for pat, label in PATTERNS:
    hits = []
    for f in texts:
        try:
            for i, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
                if re.search(pat, line, re.I):
                    hits.append(f"{f.relative_to(ROOT)}:{i}")
        except UnicodeDecodeError:
            continue
    if hits:
        errors.append(f"敏感信息[{label}]：{', '.join(hits[:5])}")
    else:
        oks.append(f"无敏感信息：{label}")

# 6. 不该入库的文件
for bad in ROOT.rglob("*.pyc"):
    warn(f"缓存文件 {bad.relative_to(ROOT)}")
for bad in ROOT.rglob("odoo.config.json"):
    errors.append(f"真实配置 {bad.relative_to(ROOT)} 禁止发布！")
for bad in ROOT.rglob("sales_raw.json"):
    errors.append(f"真实业务数据 {bad.relative_to(ROOT)} 禁止发布！")

for o in oks:
    print(f"  [OK]   {o}")
for w in warns:
    print(f"  [WARN] {w}")
for e in errors:
    print(f"  [ERR]  {e}")

print(f"\n通过 {len(oks)} 项，警告 {len(warns)} 项，错误 {len(errors)} 项")
if errors:
    print("结论：❌ 请先修复再发布")
    sys.exit(1)
print("结论：✅ 可以开源发布")
sys.exit(0)
