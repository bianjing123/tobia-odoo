# Odoo Connector for WorkBuddy

> 在 WorkBuddy 对话里直接查 Odoo 数据、推进审批流、生成报表。  
> **零第三方依赖 · 覆盖 Odoo 14-20 · 自带配置向导 · 3 分钟上手**

| 特性        | 说明                                                                         |
| --------- | -------------------------------------------------------------------------- |
| 🔌 两种模式   | `native`（XML-RPC，Odoo 14-20 / Community / 自建）和 `bridge`（Odoo 20 官方 `/mcp`） |
| 🛠 16 个工具 | 查询、审批流、元数据、报表附件全覆盖                                                         |
| 🧙 配置向导   | 问答式填写，密钥隐藏输入，当场验证连接，**不碰 JSON**                                            |
| 📦 零依赖    | 只需 Python 3.9+，`pip install` 都不用                                           |
| 🔐 密钥安全   | 向导隐藏输入，密钥只写本地配置；不进对话、不提交仓库                                                   |

---

## 快速开始（3 分钟）

### 第 1 步：安装插件（市场方式）

在 WorkBuddy 对话框粘贴（**若你 fork 了本仓库，把 `odoo-ou-tech` 换成你自己的 GitHub 用户名**）：

```
添加插件市场 odoo-ou-tech/odoo-connector，安装 odoo-connector 插件
```

或命令行：

```bash
codebuddy plugin marketplace add odoo-ou-tech/odoo-connector
codebuddy plugin install odoo-connector@odoo-connector
```

> 市场安装只负责把插件放进 WorkBuddy，连接参数还要走第 2 步向导。  
> 如果你是 clone 源码，这一步可跳过，`setup.py` 会直接完成安装。

### 第 2 步：一键安装 + 配置（一个脚本）

在仓库根目录，双击 **`setup.bat`**（Windows），或运行：

```bash
python setup.py
# Windows 若 python 不在 PATH，可试：py setup.py
```

**一个脚本依次完成**：问答填连接参数 → 当场验证 → 复制插件到 WorkBuddy → 写配置到安装目录 → 注册 MCP → 装 Skill。密钥输入时不显示，验证失败不会写入半成品，**全程不用手改 JSON**。

> 也可以直接在对话里说：**"帮我配置 Odoo 连接"**，AI 会引导你运行向导；不会让你把密钥贴进对话。

**API Key 怎么拿**：Odoo 头像 → Preferences → Security → Add API Key。  
老版本没有 API Key？选密码认证即可。

### 第 3 步：重启 WorkBuddy，开聊

改完配置需重启 WorkBuddy（或输入 `/reload-plugins`）让 MCP 重新加载。

然后直接用自然语言：

```
帮我查最近 10 个已确认的销售订单
把订单 S00001 确认掉
给我出一份上个月的销售报表
```

先验证连接：说一句 **"用 odoo_ping 检查 Odoo 连接"**。

---

## 两种模式怎么选

| 模式           | 通道          | 版本覆盖                                       | 适合谁                    |
| ------------ | ----------- | ------------------------------------------ | ---------------------- |
| `native`（默认） | 自研 XML-RPC  | Odoo 14-20，Community / Enterprise / Online | 老版本、Community、审批流要开箱可用 |
| `bridge`     | 透传官方 `/mcp` | 仅 Odoo 20 Enterprise / Online              | 想用 Odoo 官方 MCP 治理能力    |

`bridge` 模式只需在向导里选模式 2，填 scope=MCP 的 API Key。  
官方 MCP 默认只读，写操作要在 Odoo 后台 Server Actions 勾选 "Available in MCP"。

---

## native 模式 16 个工具速查

<details>

<summary>点击展开</summary>

| 类别   | 工具                                                                                         |
| ---- | ------------------------------------------------------------------------------------------ |
| 诊断   | `odoo_ping`                                                                                |
| 查询   | `odoo_search_read`、`odoo_search_count`、`odoo_read`、`odoo_get_record`                       |
| 元数据  | `odoo_list_models`、`odoo_get_fields`、`odoo_model_info`、`odoo_check_access`、`odoo_context`  |
| 工作流  | `odoo_call_method`、`odoo_execute_action`                                                   |
| 报表附件 | `odoo_list_reports`、`odoo_render_report`、`odoo_get_attachments`、`odoo_download_attachment` |

配套 `skills/odoo-connector/SKILL.md` 会教 AI 何时用哪个工具、审批流怎么推进、domain 怎么写。

</details>

> `bridge` 模式的工具由 Odoo 官方 `/mcp` 动态暴露，不固定为这 16 个；用 `odoo_bridge_status` 查看实际列表。

---

## 配置方式（进阶）

推荐路径（setup 向导）：安装目录的 `config/odoo.config.json` 是唯一真相源；setup 会清空 `mcp.json` 里会覆盖它的 `ODOO_*` env，避免"填了不生效"。

底层加载优先级仍是：**环境变量 > `config/odoo.config.json` > 默认值**。高级用户可手动用环境变量：

```bash
ODOO_URL=https://erp.example.com
ODOO_DB=my_database
ODOO_USER=admin@example.com
ODOO_API_KEY=你的Key
```

- `python setup.py --check`：查看当前生效配置（脱敏，不显示密钥）
- `python setup.py --install-only`：只升级插件、不改配置
- `python check.py`：检查仓库结构、清单、敏感信息是否适合发布

---

## 安全说明

- API Key / 密码**不要贴进对话**，用向导输入或写本地配置
- `config/odoo.config.json` 已在 `.gitignore` 中，不会被提交；setup 会尝试设为仅当前用户可读（Windows 以系统权限为准）
- 默认禁止 `create` / `write` / `unlink` 与私有方法；`odoo_call_method` 走白名单
- 写操作会真实改动 Odoo 数据，请先用测试库，正式库用受限账号
- `bridge` 模式的 Key 需要 `scope=MCP`，不要用管理员全权限 Key

---

## 目录结构

```
odoo-connector/
├── .codebuddy-plugin/
│   ├── plugin.json          # 插件清单
│   └── marketplace.json     # 市场清单（source: "./" 根目录即插件）
├── .mcp.json                # MCP server 声明
├── .gitignore               # 排除配置、密钥、业务数据
├── odoo_mcp_server.py       # MCP 入口
├── server/                  # 核心：客户端 / 工具 / 协议 / 桥接
├── skills/odoo-connector/   # 配套 Skill
├── config/                  # 配置模板
├── setup.py / setup.bat     # 一键安装向导（安装+配置+验证）
└── check.py                 # 发布自检（结构 / 清单 / 敏感信息）
```

## 常见问题

- **双击 `setup.bat` 没反应？** 确认在仓库根目录运行；若闪退，改用命令行 `python setup.py` 看报错，或试 `py setup.py`。
- **连接验证失败？** 核对 URL、数据库名、账号；API Key 在 Odoo 头像 → Preferences → Security 里生成；老版本没有 API Key 就选密码认证。
- **bridge 模式工具很少？** 仅 Odoo 20 Enterprise / Online 支持；需要用 `scope=MCP` 的 Key，并在后台 Server Actions 勾选 "Available in MCP" 才会暴露写操作。
- **改了配置没生效？** 先跑 `python setup.py --check` 看生效位置，再重启 WorkBuddy 或输入 `/reload-plugins`；不要用 `ODOO_CONFIG_FILE` 指向对话里的临时文件。

## License

MIT · 边境 / 沈阳欧度科技
