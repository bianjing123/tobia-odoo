@echo off
chcp 65001 >nul 2>&1
setlocal
cd /d "%~dp0"

echo.
echo   Odoo Connector - One-Click Setup
echo   --------------------------------
echo.

where python >nul 2>&1
if errorlevel 1 goto TRY_PY
set "PYCMD=python"
goto RUN_SETUP

:TRY_PY
where py >nul 2>&1
if errorlevel 1 goto NO_PYTHON
set "PYCMD=py -3"
goto RUN_SETUP

:NO_PYTHON
echo   [ERROR] Python not found.
echo   Install Python 3.9+ and add it to PATH:
echo   https://www.python.org/downloads/
echo.
pause
exit /b 1

:RUN_SETUP
call %PYCMD% setup.py %*
set "SETUP_RC=%errorlevel%"

echo.
echo   --------------------------------
if not "%SETUP_RC%"=="0" goto SETUP_FAIL
echo   Setup finished. Restart WorkBuddy.
goto SETUP_END

:SETUP_FAIL
echo   Setup ended (config not completed).

:SETUP_END
echo.
pause
endlocal
