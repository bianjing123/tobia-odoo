---
name: odoo-connector
description: 通过 Odoo MCP 连接器操作 ERP 数据。当用户提到查 Odoo/ERP 数据、销售订单、采购、库存、客户、发票、审批流、报表、Odoo 模型字段等，且需要真实读写 Odoo 业务数据而非泛泛而谈时使用。提供 native（自研 XML-RPC，全版本）与 bridge（Odoo 20 官方 MCP）两种模式的工具选用指引。
---

# Odoo Connector 使用指引

本 skill 配合 `odoo-connector` MCP 插件使用。连接器有两种模式，工具集不同。

## 第零步：配置意图（用户要"配置 / 连接 / 改 Odoo 账号"时）

当用户说「配置 Odoo」「连接我的 Odoo」「改一下数据库/账号」「API Key 过期了」等，**优先走配置向导**，不要让用户手改 JSON：

1. 判断用户环境：
   - Windows 桌面用户 → 让他双击插件目录里的 **`setup.bat`**（一个入口：填配置→验证→安装→注册→装 Skill，全自动）
   - 想让我代填 → 用非交互模式，把用户给的值通过参数传入（**API Key 绝不能贴进对话**，让用户自己在向导里输入）
2. 查看当前状态：`python setup.py --check`（脱敏，不显示密钥）
3. 非交互代填示例（仅在用户明确提供非敏感值时使用）：
   ```
   python setup.py --non-interactive --url <URL> --db <库名> --user <账号> --verify
   ```
   注意：不带 `--api-key`，让用户随后自己运行向导补密钥，避免密钥进入对话记录。
4. 配置写入的是**安装目录**的 `config/odoo.config.json`（gitignore 已排除），并清空 mcp.json 里会覆盖它的 env——这是"填了就生效"的关键。**不要用 ODOO_CONFIG_FILE 指向对话里的临时文件。**
5. 只升级插件不改配置：`python setup.py --install-only`。
6. 提醒：改完重启 WorkBuddy 或输入 `/reload-plugins` 才生效。

## 第一步：确认模式

- 对话中若出现 `odoo_ping` / `odoo_search_read` 等 → **native 模式**（自研，全版本）
- 若出现 `odoo_bridge_status` 或来自官方的工具名 → **bridge 模式**（Odoo 20 官方 /mcp）

不确定时，先调用对应诊断工具（`odoo_ping` 或 `odoo_bridge_status`）。

## 核心原则

1. **先发现，再操作**：不确定的模型名/字段名，先用 `odoo_list_models` / `odoo_get_fields` 查清楚，不要猜。
2. **先读后写**：推进审批流前，先用 `odoo_search_read` 确认目标记录的 `id` 和当前 `state`。
3. **权限意识**：`odoo_check_access` 可确认当前用户能否执行某操作。
4. **写操作有边界**：native 模式禁止 `create`/`write`/`unlink` 与私有方法；`odoo_call_method` 走白名单。

## native 模式工具选择

| 意图 | 工具 | 关键参数 |
|---|---|---|
| 测连接/排错 | `odoo_ping` | 无 |
| 查一批记录 | `odoo_search_read` | model, domain, fields, limit, offset, order |
| 只要条数 | `odoo_search_count` | model, domain |
| 已知 ID 读多条 | `odoo_read` | model, ids, fields |
| 已知 ID 读一条 | `odoo_get_record` | model, id |
| 列模型 | `odoo_list_models` | filter（可选） |
| 查字段 | `odoo_get_fields` | model, filter（可选） |
| 模型概要+权限 | `odoo_model_info` | model |
| 推进审批/按钮 | `odoo_call_method` | model, ids, method, args?, kwargs?, context? |
| 执行服务端动作 | `odoo_execute_action` | action（xmlid/名称/ID）, record_ids?, model? |
| 查权限 | `odoo_check_access` | model, operation |
| 看会话上下文 | `odoo_context` | 无 |
| 列报表 | `odoo_list_reports` | filter（可选） |
| 生成报表 | `odoo_render_report` | report, record_ids, converter?, output_path? |
| 查附件 | `odoo_get_attachments` | model?, record_id?, limit? |
| 下载附件 | `odoo_download_attachment` | attachment_id, output_path? |

### domain 写法

```json
[["state", "=", "sale"]]
[["&"], ["amount_total", ">", 5000], ["date_order", ">=", "2026-01-01"]]
```

参数可传 JSON 数组或字符串形式的 JSON。

### 常见模型速记

| 业务 | 模型 |
|---|---|
| 销售订单 | `sale.order` / 行 `sale.order.line` |
| 采购订单 | `purchase.order` |
| 客户/供应商 | `res.partner` |
| 产品 | `product.template` / `product.product` |
| 库存移动 | `stock.move` / `stock.picking` |
| 发票 | `account.move` |
| 销售报表 | 用 `odoo_list_reports` 查实际 report_name |

模型名因安装模块而异，拿不准就用 `odoo_list_models` 模糊搜索（如 filter="sale"）。

### 审批流推进范式

```
1. odoo_search_read  → 找到目标 id 与当前 state
2. odoo_get_fields   → 确认可用的按钮方法对应的 state 流转（必要时）
3. odoo_call_method  → ids=[id], method="action_confirm"（或对应动作）
4. odoo_get_record   → 复核 state 已变更
```

动作名因模块定制而异，不要硬套 `action_confirm`。查不到就问用户或看模型源码。

### 报表与附件落盘

- `odoo_render_report` 和 `odoo_download_attachment` 把文件写到本地 `output/`
- 返回的是**文件路径**，在回复里明确告诉用户文件在哪
- 可用 `output_path` 参数指定具体路径（相对路径基于 output 目录）

## bridge 模式注意

- 工具由 Odoo 后台 Server Actions 的 "Available in MCP" 勾选决定，默认只有 5 个只读工具
- 工具名和 schema 来自 Odoo 官方，本 skill 的 native 工具表不适用
- 需要写操作时，让用户在 Odoo 后台先暴露对应动作
- `odoo_bridge_status` 可看官方暴露了多少工具

## 安全提醒

- 不要让用户把 API Key 贴进对话；引导写入 `odoo.config.json`
- 涉及批量写/删除时，先向用户确认范围与数量
- 报表/附件路径含中文或空格时，用返回的原始路径，不要二次改写
