"""Odoo XML-RPC 客户端封装。

Odoo 从 v8 到 v20 的 XML-RPC 外部 API 保持稳定：
  - /xmlrpc/2/common  : version(), authenticate()
  - /xmlrpc/2/object  : execute_kw(db, uid, password, model, method, args, kwargs)

API Key 的调用方式与 password 完全一致，只是传入 API Key 字符串。
"""

from __future__ import annotations

import socket
import ssl
import xmlrpc.client
from typing import Any
from urllib.parse import urlparse

from .config import Config


class OdooError(Exception):
    """归一化后的 Odoo 调用错误。"""

    def __init__(self, message: str, *, kind: str = "error", detail: Any = None):
        super().__init__(message)
        self.message = message
        self.kind = kind
        self.detail = detail


class OdooClient:
    """轻量、无第三方依赖的 Odoo XML-RPC 客户端。"""

    def __init__(self, config: Config):
        self.config = config
        self._uid: int | None = None
        self._version_info: dict | None = None
        self._common_proxy: xmlrpc.client.ServerProxy | None = None
        self._object_proxy: xmlrpc.client.ServerProxy | None = None

    # ---------- 传输层 ----------

    def _transport(self) -> xmlrpc.client.Transport:
        # 注意：Python 3.x 的 Transport/SafeTransport 构造函数不接受 timeout 参数，
        # timeout 是实例属性，由 make_connection() 读取。
        timeout = self.config.timeout
        if urlparse(self.config.url).scheme == "https":
            context = None
            if not self.config.verify_ssl:
                context = ssl._create_unverified_context()
            transport = xmlrpc.client.SafeTransport(
                use_builtin_types=False, context=context
            )
        else:
            transport = xmlrpc.client.Transport(use_builtin_types=False)
        transport.timeout = timeout
        return transport

    def _server(self, path: str) -> xmlrpc.client.ServerProxy:
        return xmlrpc.client.ServerProxy(
            self.config.url + path,
            transport=self._transport(),
            allow_none=True,
        )

    @property
    def common(self) -> xmlrpc.client.ServerProxy:
        if self._common_proxy is None:
            self._common_proxy = self._server("/xmlrpc/2/common")
        return self._common_proxy

    @property
    def object(self) -> xmlrpc.client.ServerProxy:
        if self._object_proxy is None:
            self._object_proxy = self._server("/xmlrpc/2/object")
        return self._object_proxy

    # ---------- 连接与认证 ----------

    def version(self) -> dict:
        """获取 Odoo 服务器版本信息（无需认证）。"""
        if self._version_info is not None:
            return self._version_info
        try:
            info = self.common.version()
        except (OSError, socket.timeout, xmlrpc.client.Error) as exc:
            raise OdooError(
                f"无法连接 Odoo 服务器 {self.config.url}：{exc}",
                kind="connection",
                detail=str(exc),
            ) from exc
        self._version_info = dict(info or {})
        return self._version_info

    def authenticate(self) -> int:
        """登录并返回 uid，结果会被缓存。"""
        if self._uid is not None:
            return self._uid

        problems = self.config.validate()
        if problems:
            raise OdooError(
                "Odoo 连接配置不完整：" + "；".join(problems), kind="config"
            )

        try:
            uid = self.common.authenticate(
                self.config.db,
                self.config.user,
                self.config.credential,
                {},
            )
        except (OSError, socket.timeout, xmlrpc.client.Error) as exc:
            raise OdooError(
                f"Odoo 认证请求失败：{exc}", kind="connection", detail=str(exc)
            ) from exc

        if not uid:
            raise OdooError(
                f"认证失败：数据库 [{self.config.db}] 中用户 [{self.config.user}] "
                f"的凭据无效（认证方式：{self.config.auth_mode}）",
                kind="auth",
            )

        self._uid = int(uid)
        return self._uid

    def reset_auth(self) -> None:
        """凭据变更后强制重新认证。"""
        self._uid = None

    # ---------- 通用调用 ----------

    def execute(
        self,
        model: str,
        method: str,
        *args: Any,
        context: dict | None = None,
        **kwargs: Any,
    ) -> Any:
        """调用任意 Odoo 模型方法（execute_kw）。"""
        uid = self.authenticate()
        call_kwargs = dict(kwargs)
        if context is not None:
            call_kwargs["context"] = context

        try:
            return self.object.execute_kw(
                self.config.db,
                uid,
                self.config.credential,
                model,
                method,
                list(args),
                call_kwargs,
            )
        except xmlrpc.client.Fault as exc:
            raise OdooError(
                f"Odoo 调用 {model}.{method} 失败：{exc.faultString}",
                kind="odoo_fault",
                detail={"faultCode": exc.faultCode, "faultString": exc.faultString},
            ) from exc
        except (OSError, socket.timeout) as exc:
            raise OdooError(
                f"调用 {model}.{method} 时网络错误：{exc}",
                kind="connection",
                detail=str(exc),
            ) from exc
        except xmlrpc.client.Error as exc:
            raise OdooError(
                f"调用 {model}.{method} 时 XML-RPC 错误：{exc}",
                kind="xmlrpc",
                detail=str(exc),
            ) from exc

    # ---------- 常用封装 ----------

    def search_read(
        self,
        model: str,
        domain: list | None = None,
        fields: list[str] | None = None,
        limit: int = 20,
        offset: int = 0,
        order: str | None = None,
    ) -> list[dict]:
        kwargs: dict[str, Any] = {"limit": limit, "offset": offset}
        if fields:
            kwargs["fields"] = fields
        if order:
            kwargs["order"] = order
        return self.execute(model, "search_read", domain or [], **kwargs)

    def search_count(self, model: str, domain: list | None = None) -> int:
        return int(self.execute(model, "search_count", domain or []))

    def read(self, model: str, ids: list[int], fields: list[str] | None = None) -> list[dict]:
        kwargs = {"fields": fields} if fields else {}
        return self.execute(model, "read", ids, **kwargs)

    def fields_get(self, model: str, attributes: list[str] | None = None) -> dict:
        attrs = attributes or ["string", "type", "required", "readonly", "selection", "relation"]
        return self.execute(model, "fields_get", [], {"attributes": attrs})

    def check_access(self, model: str, operation: str = "read") -> bool:
        return bool(
            self.execute(
                model, "check_access_rights", [operation], raise_exception=False
            )
        )

    def get_ref(self, xmlid: str) -> int | None:
        """通过 external ID 解析记录 ID。"""
        if "." not in xmlid:
            return None
        module, name = xmlid.split(".", 1)
        records = self.execute(
            "ir.model.data", "search_read", [("module", "=", module), ("name", "=", name)],
            fields=["res_id"], limit=1,
        )
        return int(records[0]["res_id"]) if records else None
