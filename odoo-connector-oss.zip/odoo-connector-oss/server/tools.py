"""MCP 工具定义与调度。

能力分三类（按用户需求）：
  1. 查询记录：search_read / search_count / read / get_record
  2. 工作流与动作：call_method / execute_action / check_access / context
  3. 元数据与报表：list_models / get_fields / model_info / list_reports /
                   render_report / get_attachments / download_attachment
外加连接诊断：ping
"""

from __future__ import annotations

import base64
import json
import re
import xmlrpc.client
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable

from .config import Config
from .odoo_client import OdooClient, OdooError


# ---------------------------------------------------------------------------
# 序列化辅助
# ---------------------------------------------------------------------------

def _json_default(obj: Any):
    """把 Odoo/XML-RPC 的特殊类型转成 JSON 可序列化值。"""
    if isinstance(obj, xmlrpc.client.DateTime):
        return obj.value
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, bytes):
        return base64.b64encode(obj).decode("ascii")
    if isinstance(obj, set):
        return sorted(obj)
    return str(obj)


def _dump(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2, default=_json_default)


def _parse_domain(value: Any) -> list:
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ValueError(f"domain 不是合法 JSON 数组：{exc}") from exc
        if not isinstance(parsed, list):
            raise ValueError("domain 必须是 JSON 数组，例如 [['name','ilike','Acme']]")
        return parsed
    raise ValueError("domain 必须是数组或 JSON 字符串")


def _as_int_list(value: Any) -> list[int]:
    if value is None:
        return []
    if isinstance(value, (int, str)) and str(value).isdigit():
        value = [value]
    if not isinstance(value, list):
        raise ValueError("ids 必须是整数数组，例如 [12, 34]")
    out = []
    for item in value:
        try:
            out.append(int(item))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"ids 中包含非法值：{item!r}") from exc
    return out


def _as_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "on")


def _safe_filename(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|\r\n]+', "_", str(name)).strip() or "download"


# ---------------------------------------------------------------------------
# 安全守卫
# ---------------------------------------------------------------------------

_DANGEROUS_METHODS = {
    "create", "write", "unlink", "copy", "sudo", "with_user", "with_context",
    "execute", "execute_kw", "eval", "export_data", "export_data2",
    "import_data", "load", "flush", "flush_all", "env", "refresh",
    "action_unlink", "unlink_from_view", "toggle_active",
}


def _guard_model(model: str, config: Config) -> str:
    model = (model or "").strip()
    if not model:
        raise ValueError("model 不能为空")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", model):
        raise ValueError(f"模型名不合法：{model!r}")
    allowed = config.allowed_models
    if allowed and model not in allowed:
        raise ValueError(
            f"模型 {model} 不在白名单中。当前白名单：{', '.join(allowed)}。"
            "如需放开，请设置 ODOO_ALLOWED_MODELS。"
        )
    return model


def _guard_method(method: str, config: Config) -> str:
    method = (method or "").strip()
    if not method:
        raise ValueError("method 不能为空")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", method):
        raise ValueError(f"方法名不合法：{method!r}")
    if method.startswith("_") or method in _DANGEROUS_METHODS:
        raise ValueError(
            f"出于安全考虑禁止调用方法 {method}（私有方法或数据写入/删除类方法）。"
        )
    allowed = config.allowed_methods
    if allowed and "*" not in allowed and method not in allowed:
        raise ValueError(
            f"方法 {method} 不在白名单中。如需允许，请把它加入 "
            "ODOO_ALLOWED_METHODS（逗号分隔），或设为 * 允许全部非危险方法。"
        )
    return method


# ---------------------------------------------------------------------------
# 工具清单（MCP inputSchema 用 JSON Schema draft-07 风格）
# ---------------------------------------------------------------------------

def _obj(properties: dict, required: list[str] | None = None) -> dict:
    schema: dict[str, Any] = {"type": "object", "properties": properties}
    if required:
        schema["required"] = required
    return schema


S = {"type": "string"}
I = {"type": "integer"}
B = {"type": "boolean"}
ARR = {"type": "array", "items": {}}
STR_ARR = {"type": "array", "items": {"type": "string"}}
OBJ = {"type": "object"}
DOMAIN = {
    "description": "Odoo domain 过滤条件，数组或 JSON 字符串，例如 [['name','ilike','Acme']]",
    "oneOf": [
        {"type": "array", "items": {}},
        {"type": "string"},
    ],
}

TOOLS: list[dict] = [
    {
        "name": "odoo_ping",
        "description": (
            "测试 Odoo 连接并诊断配置。返回服务器版本、认证用户 uid、"
            "当前连接参数摘要（不含密码/API Key）。任何 Odoo 操作前可先用它排查。"
        ),
        "inputSchema": _obj({}),
    },
    {
        "name": "odoo_search_read",
        "description": (
            "按 domain 条件搜索并读取模型记录（最常用）。支持字段筛选、分页、排序。"
            "例：查销售订单 model='sale.order', domain=[['state','=','sale']]。"
        ),
        "inputSchema": _obj({
            "model": {"type": "string", "description": "Odoo 模型名，如 sale.order"},
            "domain": DOMAIN,
            "fields": {**STR_ARR, "description": "要返回的字段名；留空返回全部字段"},
            "limit": {"type": "integer", "description": "最多返回条数，默认 20", "default": 20},
            "offset": {"type": "integer", "description": "跳过条数，默认 0", "default": 0},
            "order": {"type": "string", "description": "排序，如 'date_order desc'"},
        }, ["model"]),
    },
    {
        "name": "odoo_search_count",
        "description": "统计符合 domain 条件的记录数量，不返回记录本身。",
        "inputSchema": _obj({"model": S, "domain": DOMAIN}, ["model"]),
    },
    {
        "name": "odoo_read",
        "description": "按已知 ID 列表读取模型记录。",
        "inputSchema": _obj({
            "model": S,
            "ids": {"type": "array", "items": {"type": "integer"}, "description": "记录 ID 数组"},
            "fields": {**STR_ARR, "description": "要返回的字段；留空返回全部"},
        }, ["model", "ids"]),
    },
    {
        "name": "odoo_get_record",
        "description": "按单个 ID 读取一条记录；找不到时明确报错。",
        "inputSchema": _obj({
            "model": S, "id": I,
            "fields": {**STR_ARR, "description": "要返回的字段；留空返回全部"},
        }, ["model", "id"]),
    },
    {
        "name": "odoo_call_method",
        "description": (
            "调用模型的某个方法/按钮方法，用于推进工作流（如 action_confirm、"
            "action_approve）。只允许调用白名单中的非危险方法，不会执行 create/"
            "write/unlink 等数据写入删除方法。调用前可用 odoo_get_fields / "
            "odoo_model_info 确认模型与方法。"
        ),
        "inputSchema": _obj({
            "model": S,
            "ids": {"type": "array", "items": {"type": "integer"}, "description": "目标记录 ID 数组"},
            "method": {"type": "string", "description": "方法名，如 action_confirm"},
            "args": {"type": "array", "items": {}, "description": "位置参数，默认空数组"},
            "kwargs": {"type": "object", "description": "关键字参数（不含 context）"},
            "context": {"type": "object", "description": "额外的 Odoo context"},
        }, ["model", "ids", "method"]),
    },
    {
        "name": "odoo_execute_action",
        "description": (
            "执行 ir.actions.server 服务端动作。action 可传 external ID"
            "（如 'sale.action_quotations_send'）、动作名或数字 ID。"
            "会自动把 record_ids 放进 context 的 active_model/active_ids。"
        ),
        "inputSchema": _obj({
            "action": {"type": "string", "description": "external ID、动作名或数字 ID"},
            "record_ids": {"type": "array", "items": {"type": "integer"}, "description": "上下文记录 ID"},
            "model": {"type": "string", "description": "上下文模型名（可选，用于 active_model）"},
            "extra_context": {"type": "object", "description": "额外 context 键值对"},
        }, ["action"]),
    },
    {
        "name": "odoo_check_access",
        "description": "检查当前用户对某模型的读/写/创建/删除权限，返回 true/false。",
        "inputSchema": _obj({
            "model": S,
            "operation": {"type": "string", "enum": ["read", "write", "create", "unlink"], "default": "read"},
        }, ["model"]),
    },
    {
        "name": "odoo_context",
        "description": "获取当前登录用户、公司、语言、时区等会话上下文。",
        "inputSchema": _obj({}),
    },
    {
        "name": "odoo_list_models",
        "description": "列出 Odoo 中的模型（按技术名或显示名模糊过滤），用于发现可用的 model。",
        "inputSchema": _obj({
            "filter": {"type": "string", "description": "模糊过滤关键字，留空列出全部"},
            "limit": {"type": "integer", "description": "最多返回条数，默认 100", "default": 100},
        }),
    },
    {
        "name": "odoo_get_fields",
        "description": (
            "查询某模型的字段定义（名称、类型、标签、必填、关联模型、选项值等）。"
            "在写 domain 或调用方法前用它确认字段名。"
        ),
        "inputSchema": _obj({
            "model": S,
            "filter": {"type": "string", "description": "只返回字段名/标签包含该关键字的字段"},
        }, ["model"]),
    },
    {
        "name": "odoo_model_info",
        "description": "查看模型概要：显示名、字段数量、记录总数、当前用户权限。",
        "inputSchema": _obj({"model": S}, ["model"]),
    },
    {
        "name": "odoo_list_reports",
        "description": "列出可用的报表动作（ir.actions.report），用于后续 odoo_render_report。",
        "inputSchema": _obj({
            "filter": {"type": "string", "description": "按报表名/技术名模糊过滤"},
            "limit": {"type": "integer", "description": "最多返回条数，默认 50", "default": 50},
        }),
    },
    {
        "name": "odoo_render_report",
        "description": (
            "生成报表并保存到本地文件，返回文件路径与大小（不把大文件塞进对话）。"
            "report 可传 external ID、报表技术名（report_name）或数字 ID。"
            "converter 支持 pdf/html/xlsx/csv/text，默认 pdf。"
        ),
        "inputSchema": _obj({
            "report": {"type": "string", "description": "报表的 external ID / 技术名 / 数字 ID"},
            "record_ids": {"type": "array", "items": {"type": "integer"}, "description": "要打印的记录 ID"},
            "converter": {"type": "string", "enum": ["pdf", "html", "xlsx", "csv", "text"], "default": "pdf"},
            "output_path": {"type": "string", "description": "可选：指定输出文件路径（含扩展名）"},
            "data": {"type": "object", "description": "可选：传给报表的额外 data 字典"},
        }, ["report", "record_ids"]),
    },
    {
        "name": "odoo_get_attachments",
        "description": "查询附件（ir.attachment）元数据，可按模型和记录 ID 过滤。",
        "inputSchema": _obj({
            "model": {"type": "string", "description": "可选：关联模型，如 sale.order"},
            "record_id": {"type": "integer", "description": "可选：关联记录 ID"},
            "limit": {"type": "integer", "description": "最多返回条数，默认 50", "default": 50},
        }),
    },
    {
        "name": "odoo_download_attachment",
        "description": "把附件的二进制内容保存到本地文件，返回路径与大小。",
        "inputSchema": _obj({
            "attachment_id": {"type": "integer", "description": "附件 ID"},
            "output_path": {"type": "string", "description": "可选：指定输出文件路径"},
        }, ["attachment_id"]),
    },
]


# ---------------------------------------------------------------------------
# 工具实现
# ---------------------------------------------------------------------------

def _t_ping(a: dict, c: OdooClient, cfg: Config) -> dict:
    version = c.version()
    uid = c.authenticate()
    return {
        "ok": True,
        "server_version": (
            version.get("server_version")
            or version.get("version")
            or (version.get("version_info") or [None])[0]
        ),
        "server_info": version,
        "uid": uid,
        "config": cfg.safe_summary(),
    }


def _t_search_read(a: dict, c: OdooClient, cfg: Config) -> dict:
    model = _guard_model(a.get("model"), cfg)
    domain = _parse_domain(a.get("domain"))
    fields = a.get("fields") or []
    limit = int(a.get("limit") or 20)
    offset = int(a.get("offset") or 0)
    order = a.get("order")
    records = c.search_read(model, domain, fields, limit, offset, order)
    return {"model": model, "count": len(records), "records": records}


def _t_search_count(a: dict, c: OdooClient, cfg: Config) -> dict:
    model = _guard_model(a.get("model"), cfg)
    return {"model": model, "count": c.search_count(model, _parse_domain(a.get("domain")))}


def _t_read(a: dict, c: OdooClient, cfg: Config) -> dict:
    model = _guard_model(a.get("model"), cfg)
    ids = _as_int_list(a.get("ids"))
    if not ids:
        raise ValueError("ids 不能为空")
    return {"model": model, "records": c.read(model, ids, a.get("fields") or [])}


def _t_get_record(a: dict, c: OdooClient, cfg: Config) -> dict:
    model = _guard_model(a.get("model"), cfg)
    rid = int(a["id"])
    rows = c.read(model, [rid], a.get("fields") or [])
    if not rows:
        raise ValueError(f"{model} 中不存在 ID={rid} 的记录（或无读取权限）")
    return {"model": model, "record": rows[0]}


def _t_call_method(a: dict, c: OdooClient, cfg: Config) -> dict:
    model = _guard_model(a.get("model"), cfg)
    method = _guard_method(a.get("method"), cfg)
    ids = _as_int_list(a.get("ids"))
    if not ids:
        raise ValueError("ids 不能为空")
    args = a.get("args") or []
    kwargs = dict(a.get("kwargs") or {})
    context = a.get("context")
    result = c.execute(model, method, ids, *args, context=context, **kwargs)
    return {"model": model, "ids": ids, "method": method, "result": result}


def _t_execute_action(a: dict, c: OdooClient, cfg: Config) -> dict:
    action = str(a.get("action") or "").strip()
    if not action:
        raise ValueError("action 不能为空")
    action_id: int | None = None

    if action.isdigit():
        action_id = int(action)
    elif "." in action:
        action_id = c.get_ref(action)
        if not action_id:
            raise ValueError(f"找不到 external ID 对应的记录：{action}")
    else:
        rows = c.search_read(
            "ir.actions.server", [("name", "=", action)], fields=["id"], limit=1
        )
        if rows:
            action_id = int(rows[0]["id"])

    if not action_id:
        # 退一步：按名称模糊找
        rows = c.search_read(
            "ir.actions.server", [("name", "ilike", action)], fields=["id", "name"], limit=5
        )
        if len(rows) == 1:
            action_id = int(rows[0]["id"])
        elif rows:
            raise ValueError(
                "动作名匹配到多条，请改用 external ID 或数字 ID："
                + ", ".join(f"{r['id']}={r['name']}" for r in rows)
            )
        else:
            raise ValueError(f"找不到服务端动作：{action}")

    record_ids = _as_int_list(a.get("record_ids"))
    ctx: dict[str, Any] = dict(a.get("extra_context") or {})
    if a.get("model"):
        ctx["active_model"] = a["model"]
    if record_ids:
        ctx["active_ids"] = record_ids
        ctx["active_id"] = record_ids[0]

    result = c.execute("ir.actions.server", "run", [action_id], context=ctx)
    return {"action_id": action_id, "record_ids": record_ids, "result": result}


def _t_check_access(a: dict, c: OdooClient, cfg: Config) -> dict:
    model = _guard_model(a.get("model"), cfg)
    operation = a.get("operation") or "read"
    allowed = c.check_access(model, operation)
    return {"model": model, "operation": operation, "allowed": allowed}


def _t_context(a: dict, c: OdooClient, cfg: Config) -> dict:
    uid = c.authenticate()
    rows = c.read("res.users", [uid], ["name", "login", "company_id", "company_ids", "lang", "tz"])
    return {"uid": uid, "user": rows[0] if rows else None}


def _t_list_models(a: dict, c: OdooClient, cfg: Config) -> dict:
    keyword = str(a.get("filter") or "").strip()
    domain: list = [["state", "=", "base"]]
    if keyword:
        domain = ["&"] + domain + ["|", ["model", "ilike", keyword], ["name", "ilike", keyword]]
    rows = c.search_read(
        "ir.model", domain, fields=["model", "name", "state", "transient"],
        limit=int(a.get("limit") or 100), order="model asc",
    )
    return {"count": len(rows), "models": rows}


def _t_get_fields(a: dict, c: OdooClient, cfg: Config) -> dict:
    model = _guard_model(a.get("model"), cfg)
    fields = c.fields_get(model)
    keyword = str(a.get("filter") or "").strip().lower()
    if keyword:
        fields = {
            k: v for k, v in fields.items()
            if keyword in k.lower() or keyword in str(v.get("string", "")).lower()
        }
    return {"model": model, "count": len(fields), "fields": fields}


def _t_model_info(a: dict, c: OdooClient, cfg: Config) -> dict:
    model = _guard_model(a.get("model"), cfg)
    rows = c.search_read(
        "ir.model", [("model", "=", model)], fields=["model", "name", "info", "state", "transient"], limit=1
    )
    fields = c.fields_get(model)
    count = c.search_count(model)
    return {
        "model": model,
        "label": rows[0].get("name") if rows else None,
        "state": rows[0].get("state") if rows else None,
        "field_count": len(fields),
        "record_count": count,
        "read_allowed": c.check_access(model, "read"),
        "write_allowed": c.check_access(model, "write"),
        "create_allowed": c.check_access(model, "create"),
        "unlink_allowed": c.check_access(model, "unlink"),
    }


def _t_list_reports(a: dict, c: OdooClient, cfg: Config) -> dict:
    keyword = str(a.get("filter") or "").strip()
    domain: list = []
    if keyword:
        domain = ["|", ["name", "ilike", keyword], ["report_name", "ilike", keyword]]
    rows = c.search_read(
        "ir.actions.report", domain,
        fields=["id", "name", "report_name", "report_type", "model_name", "print_report_name"],
        limit=int(a.get("limit") or 50), order="name asc",
    )
    return {"count": len(rows), "reports": rows}


def _resolve_report_ref(c: OdooClient, report: str) -> str:
    """把 report 参数解析成可用于 _render_qweb_* 的技术名 / external ID。"""
    report = report.strip()
    if report.isdigit():
        rid = int(report)
        rows = c.search_read("ir.model.data", [("model", "=", "ir.actions.report"), ("res_id", "=", rid)],
                             fields=["module", "name"], limit=1)
        if rows:
            return f"{rows[0]['module']}.{rows[0]['name']}"
        rows = c.read("ir.actions.report", [rid], ["report_name"])
        if rows:
            return str(rows[0]["report_name"])
        raise ValueError(f"找不到 ID={rid} 的报表动作")
    if "." in report:
        return report
    rows = c.search_read("ir.actions.report", [("report_name", "=", report)], fields=["report_name"], limit=1)
    if rows:
        return str(rows[0]["report_name"])
    return report


def _render_report(c: OdooClient, report_ref: str, record_ids: list[int], converter: str, data: dict) -> tuple[Any, str | None]:
    """多版本兼容地渲染报表，返回 (content, detected_format)。"""
    errors: list[str] = []

    # 路线 1：Odoo 14+ 公开 API render_report
    try:
        result = c.execute("ir.actions.report", "render_report", record_ids, report_ref, data or {})
        if isinstance(result, tuple) and len(result) >= 2:
            return result[0], str(result[1])
        return result, converter
    except OdooError as exc:
        errors.append(f"render_report: {exc.message}")

    # 路线 2：私有 qweb 渲染方法（不同版本签名不同，逐个尝试）
    method_map = {
        "pdf": "_render_qweb_pdf",
        "html": "_render_qweb_html",
        "text": "_render_qweb_text",
    }
    method = method_map.get(converter, "_render_qweb_pdf")
    for args in (
        [report_ref, record_ids],
        [report_ref, record_ids, data or {}],
        [record_ids, data or {}],
    ):
        try:
            result = c.execute("ir.actions.report", method, *args)
            if isinstance(result, tuple):
                return result[0], (str(result[1]) if len(result) > 1 else converter)
            return result, converter
        except OdooError as exc:
            errors.append(f"{method}{args}: {exc.message}")

    raise OdooError(
        "报表渲染失败，所有兼容路径均不可用。原始错误：" + " | ".join(errors[:4]),
        kind="render",
    )


def _t_render_report(a: dict, c: OdooClient, cfg: Config) -> dict:
    report_ref = _resolve_report_ref(c, str(a.get("report") or ""))
    if not report_ref:
        raise ValueError("report 不能为空")
    record_ids = _as_int_list(a.get("record_ids"))
    converter = str(a.get("converter") or "pdf").lower()
    if converter not in ("pdf", "html", "xlsx", "csv", "text"):
        raise ValueError(f"不支持的 converter：{converter}")

    content, detected = _render_report(c, report_ref, record_ids, converter, dict(a.get("data") or {}))

    if isinstance(content, str):
        payload = content.encode("utf-8")
    elif isinstance(content, bytes):
        payload = content
    else:
        payload = str(content).encode("utf-8")

    out_dir = cfg.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    if a.get("output_path"):
        out = Path(str(a["output_path"]))
        if not out.is_absolute():
            out = out_dir / out
    else:
        suffix = f".{converter}" if not str(report_ref).endswith(f".{converter}") else ""
        out = out_dir / (_safe_filename(report_ref) + "_" + "_".join(map(str, record_ids[:5])) + suffix)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(payload)

    return {
        "path": str(out.resolve()),
        "size_bytes": len(payload),
        "format": detected or converter,
        "report_ref": report_ref,
        "record_ids": record_ids,
    }


def _t_get_attachments(a: dict, c: OdooClient, cfg: Config) -> dict:
    domain: list = []
    if a.get("model"):
        domain.append(("res_model", "=", a["model"]))
    if a.get("record_id") is not None:
        domain.append(("res_id", "=", int(a["record_id"])))
    rows = c.search_read(
        "ir.attachment", domain,
        fields=["id", "name", "mimetype", "file_size", "res_model", "res_id", "create_date"],
        limit=int(a.get("limit") or 50), order="create_date desc",
    )
    return {"count": len(rows), "attachments": rows}


def _t_download_attachment(a: dict, c: OdooClient, cfg: Config) -> dict:
    aid = int(a["attachment_id"])
    rows = c.read("ir.attachment", [aid], ["name", "datas"])
    if not rows:
        raise ValueError(f"找不到 ID={aid} 的附件")
    row = rows[0]
    raw = row.get("datas") or ""
    if isinstance(raw, bytes):
        payload = raw
    else:
        try:
            payload = base64.b64decode(str(raw))
        except Exception as exc:
            raise ValueError(f"附件 {aid} 的 datas 不是合法 base64：{exc}") from exc

    out_dir = cfg.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    if a.get("output_path"):
        out = Path(str(a["output_path"]))
        if not out.is_absolute():
            out = out_dir / out
    else:
        out = out_dir / f"{aid}_{_safe_filename(row.get('name') or 'attachment')}"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(payload)

    return {
        "path": str(out.resolve()),
        "size_bytes": len(payload),
        "name": row.get("name"),
        "attachment_id": aid,
    }


# ---------------------------------------------------------------------------
# 调度
# ---------------------------------------------------------------------------

HANDLERS: dict[str, Callable[[dict, OdooClient, Config], dict]] = {
    "odoo_ping": _t_ping,
    "odoo_search_read": _t_search_read,
    "odoo_search_count": _t_search_count,
    "odoo_read": _t_read,
    "odoo_get_record": _t_get_record,
    "odoo_call_method": _t_call_method,
    "odoo_execute_action": _t_execute_action,
    "odoo_check_access": _t_check_access,
    "odoo_context": _t_context,
    "odoo_list_models": _t_list_models,
    "odoo_get_fields": _t_get_fields,
    "odoo_model_info": _t_model_info,
    "odoo_list_reports": _t_list_reports,
    "odoo_render_report": _t_render_report,
    "odoo_get_attachments": _t_get_attachments,
    "odoo_download_attachment": _t_download_attachment,
}


def call_tool(name: str, arguments: dict | None, client: OdooClient, config: Config) -> tuple[str, bool]:
    """返回 (文本结果, 是否错误)。"""
    args = arguments or {}
    if not isinstance(args, dict):
        return _dump({"error": "arguments 必须是 JSON 对象"}), True
    handler = HANDLERS.get(name)
    if handler is None:
        return _dump({"error": f"未知工具：{name}"}), True
    try:
        result = handler(args, client, config)
        return _dump(result), False
    except (OdooError, ValueError, KeyError, TypeError) as exc:
        payload = {"error": str(exc)}
        if isinstance(exc, OdooError) and exc.detail is not None:
            payload["detail"] = exc.detail
        return _dump(payload), True
    except Exception as exc:  # 兜底，保证 MCP 通道不被异常打断
        return _dump({"error": f"工具执行异常：{type(exc).__name__}: {exc}"}), True
