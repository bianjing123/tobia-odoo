"""极简 MCP stdio 服务端（JSON-RPC 2.0，换行分隔）。

不依赖 mcp SDK，只用标准库实现 WorkBuddy 所需的 MCP 方法：
  initialize / notifications/initialized / ping / tools/list / tools/call
  resources/list / prompts/list（空实现，声明能力边界）

所有日志走 stderr，stdout 只输出 JSON-RPC 消息，避免污染协议通道。
"""

from __future__ import annotations

import json
import sys
import traceback
from typing import Any, Callable

JSONRPC_VERSION = "2.0"
DEFAULT_PROTOCOL_VERSION = "2024-11-05"

PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603


def log(message: str) -> None:
    print(f"[odoo-mcp] {message}", file=sys.stderr, flush=True)


class MCPStdioServer:
    def __init__(
        self,
        name: str,
        version: str,
        tools: list[dict],
        call_handler: Callable[[str, dict | None], tuple[str, bool]],
    ):
        self.name = name
        self.version = version
        self.tools = tools
        self.call_handler = call_handler
        self.protocol_version = DEFAULT_PROTOCOL_VERSION
        self.initialized = False

    # ---------- 通道 ----------

    def _send(self, message: dict) -> None:
        sys.stdout.write(json.dumps(message, ensure_ascii=False, separators=(",", ":")) + "\n")
        sys.stdout.flush()

    def _result(self, req_id: Any, result: Any) -> None:
        self._send({"jsonrpc": JSONRPC_VERSION, "id": req_id, "result": result})

    def _error(self, req_id: Any, code: int, message: str, data: Any = None) -> None:
        error: dict[str, Any] = {"code": code, "message": message}
        if data is not None:
            error["data"] = data
        self._send({"jsonrpc": JSONRPC_VERSION, "id": req_id, "error": error})

    # ---------- 方法分发 ----------

    def _handle(self, msg: dict) -> None:
        if not isinstance(msg, dict) or msg.get("jsonrpc") != JSONRPC_VERSION:
            self._error(None, INVALID_REQUEST, "Invalid Request")
            return

        req_id = msg.get("id")
        method = msg.get("method")
        params = msg.get("params") or {}

        # 通知（无 id）不返回响应
        if "id" not in msg:
            if method == "notifications/initialized":
                self.initialized = True
            elif method == "notifications/cancelled":
                pass
            else:
                log(f"忽略未知通知：{method}")
            return

        if method == "initialize":
            self._do_initialize(req_id, params)
        elif method == "ping":
            self._result(req_id, {})
        elif method == "tools/list":
            self._result(req_id, {"tools": self.tools})
        elif method == "tools/call":
            self._do_tools_call(req_id, params)
        elif method in ("resources/list", "prompts/list"):
            self._result(req_id, {"resources": [], "prompts": []})
        elif method == "shutdown":
            self._result(req_id, {})
        elif method == "exit":
            self._result(req_id, {})
            sys.exit(0)
        else:
            self._error(req_id, METHOD_NOT_FOUND, f"Method not found: {method}")

    def _do_initialize(self, req_id: Any, params: dict) -> None:
        requested = params.get("protocolVersion") if isinstance(params, dict) else None
        if isinstance(requested, str) and requested.startswith(("2024", "2025", "2026")):
            self.protocol_version = requested
        self._result(req_id, {
            "protocolVersion": self.protocol_version,
            "capabilities": {
                "tools": {"listChanged": False},
                "logging": {},
            },
            "serverInfo": {"name": self.name, "version": self.version},
            "instructions": (
                "Odoo 连接器：先用 odoo_ping 验证连接；用 odoo_list_models / "
                "odoo_get_fields 发现模型与字段；查询用 odoo_search_read；"
                "推进审批流用 odoo_call_method 或 odoo_execute_action；"
                "报表与附件会落盘到本地文件，返回路径。"
            ),
        })

    def _do_tools_call(self, req_id: Any, params: dict) -> None:
        if not isinstance(params, dict) or "name" not in params:
            self._error(req_id, INVALID_PARAMS, "tools/call 需要 params.name")
            return
        name = str(params["name"])
        arguments = params.get("arguments")
        if arguments is not None and not isinstance(arguments, dict):
            self._error(req_id, INVALID_PARAMS, "tools/call 的 arguments 必须是对象")
            return
        try:
            text, is_error = self.call_handler(name, arguments)
        except Exception as exc:
            log(f"工具 {name} 抛异常：{exc}\n{traceback.format_exc()}")
            text, is_error = json.dumps(
                {"error": f"工具异常：{type(exc).__name__}: {exc}"}, ensure_ascii=False
            ), True

        result: dict[str, Any] = {
            "content": [{"type": "text", "text": str(text)}],
        }
        if is_error:
            result["isError"] = True
        self._result(req_id, result)

    # ---------- 主循环 ----------

    def run(self) -> int:
        log(f"{self.name} v{self.version} 已启动（stdio）")
        try:
            for line in sys.stdin:
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError as exc:
                    self._error(None, PARSE_ERROR, f"Parse error: {exc}")
                    continue

                if isinstance(msg, list):
                    for item in msg:
                        if isinstance(item, dict):
                            self._handle(item)
                else:
                    self._handle(msg)
        except KeyboardInterrupt:
            pass
        finally:
            log("已退出")
        return 0
