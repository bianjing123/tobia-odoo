"""Odoo 连接配置读取：环境变量优先，config/odoo.config.json 兜底。

零依赖，仅用标准库。
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from urllib.parse import urlparse

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = PLUGIN_ROOT / "config" / "odoo.config.json"

# 环境变量 -> 配置键
ENV_MAP = {
    "ODOO_URL": "url",
    "ODOO_DB": "db",
    "ODOO_USER": "user",
    "ODOO_PASSWORD": "password",
    "ODOO_API_KEY": "api_key",
    "ODOO_VERSION": "version",
    "ODOO_TIMEOUT": "timeout",
    "ODOO_VERIFY_SSL": "verify_ssl",
    "ODOO_ALLOWED_MODELS": "allowed_models",
    "ODOO_ALLOWED_METHODS": "allowed_methods",
    "ODOO_OUTPUT_DIR": "output_dir",
    "ODOO_CONFIG_FILE": "_config_file",
    "ODOO_MODE": "mode",
    "ODOO_MCP_URL": "mcp_url",
    "ODOO_MCP_TOKEN": "mcp_token",
}

DEFAULTS = {
    # native = 自研 XML-RPC（全版本）；bridge = Odoo 20 官方 /mcp
    "mode": "native",
    "mcp_url": "",
    "mcp_token": "",
    "url": "http://127.0.0.1:8069",
    "db": "",
    "user": "",
    "password": "",
    "api_key": "",
    "version": "20.0",
    "timeout": 30,
    "verify_ssl": True,
    # 空字符串 = 不限制；否则逗号分隔的白名单，如 "sale.order,res.partner"
    "allowed_models": "",
    # 允许调用的模型方法白名单（工作流/按钮方法）
    "allowed_methods": (
        "action_confirm,action_approve,action_done,action_cancel,"
        "button_confirm,button_approve,button_done,action_validate,"
        "action_post,action_open_quotes,action_send,"
        "action_submit,action_refuse,action_reset,action_draft"
    ),
    "output_dir": str(PLUGIN_ROOT / "output"),
}


def _to_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "on")


class Config:
    """运行时配置对象。"""

    def __init__(self, values: dict):
        self._v = values

    def get(self, key: str, default=None):
        return self._v.get(key, DEFAULTS.get(key, default))

    @property
    def mode(self) -> str:
        mode = str(self._v.get("mode") or "native").strip().lower()
        return mode if mode in ("native", "bridge") else "native"

    @property
    def mcp_url(self) -> str:
        return str(self._v.get("mcp_url") or "").strip().rstrip("/")

    @property
    def mcp_token(self) -> str:
        return str(self._v.get("mcp_token") or "").strip()

    @property
    def url(self) -> str:
        return str(self._v["url"]).rstrip("/")

    @property
    def db(self) -> str:
        return str(self._v.get("db") or "")

    @property
    def user(self) -> str:
        return str(self._v.get("user") or "")

    @property
    def credential(self) -> str:
        """API Key 优先，否则用密码。Odoo 的 API Key 就是替代 password 传入的。"""
        return str(self._v.get("api_key") or self._v.get("password") or "")

    @property
    def auth_mode(self) -> str:
        return "api_key" if self._v.get("api_key") else "password"

    @property
    def version(self) -> str:
        return str(self._v.get("version") or "20.0")

    @property
    def timeout(self) -> int:
        try:
            return int(self._v.get("timeout") or 30)
        except (TypeError, ValueError):
            return 30

    @property
    def verify_ssl(self) -> bool:
        return _to_bool(self._v.get("verify_ssl", True))

    @property
    def allowed_models(self) -> list[str]:
        raw = self._v.get("allowed_models") or ""
        return [m.strip() for m in str(raw).split(",") if m.strip()]

    @property
    def allowed_methods(self) -> list[str]:
        raw = self._v.get("allowed_methods")
        if raw is None:
            raw = DEFAULTS["allowed_methods"]
        return [m.strip() for m in str(raw).split(",") if m.strip()]

    @property
    def output_dir(self) -> Path:
        p = Path(str(self._v.get("output_dir") or DEFAULTS["output_dir"]))
        if not p.is_absolute():
            p = PLUGIN_ROOT / p
        return p

    def validate(self) -> list[str]:
        """返回配置问题列表，空列表表示 OK。"""
        problems: list[str] = []
        if self.mode == "bridge":
            # 桥接模式只需端点 + Bearer Token
            if not self.mcp_token and not self.credential:
                problems.append("桥接模式缺少 ODOO_MCP_TOKEN（scope=MCP 的 API Key）")
            endpoint = self.mcp_url or self.url.rstrip("/") + "/mcp"
            parsed = urlparse(endpoint)
            if parsed.scheme not in ("http", "https") or not parsed.netloc:
                problems.append(f"ODOO_MCP_URL / ODOO_URL 不合法：{endpoint}")
            return problems

        if not self.db:
            problems.append("缺少 ODOO_DB（数据库名）")
        if not self.user:
            problems.append("缺少 ODOO_USER（登录账号）")
        if not self.credential:
            problems.append("缺少 ODOO_API_KEY 或 ODOO_PASSWORD（凭据）")
        parsed = urlparse(self.url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            problems.append(f"ODOO_URL 不合法：{self.url}")
        return problems

    def safe_summary(self) -> dict:
        """不含任何凭据的摘要，可用于诊断工具。"""
        return {
            "mode": self.mode,
            "url": self.url,
            "mcp_url": self.mcp_url or (self.url.rstrip("/") + "/mcp" if self.mode == "bridge" else ""),
            "db": self.db,
            "user": self.user,
            "version": self.version,
            "auth_mode": self.auth_mode,
            "timeout": self.timeout,
            "verify_ssl": self.verify_ssl,
            "allowed_models": self.allowed_models or ["*"],
            "output_dir": str(self.output_dir),
        }


def load_config() -> Config:
    """加载配置：默认值 <- 配置文件 <- 环境变量。"""
    values = dict(DEFAULTS)

    config_file = os.environ.get("ODOO_CONFIG_FILE", "")
    path = Path(config_file) if config_file else DEFAULT_CONFIG_PATH
    if not path.is_absolute():
        path = PLUGIN_ROOT / path

    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for k, v in data.items():
                    if k in DEFAULTS:
                        values[k] = v
        except (OSError, json.JSONDecodeError):
            # 配置文件坏掉时不阻断启动，环境变量仍可覆盖
            pass

    for env_key, cfg_key in ENV_MAP.items():
        if env_key in os.environ and os.environ[env_key] != "":
            values[cfg_key] = os.environ[env_key]

    return Config(values)
