"""Odoo 20 官方 MCP 桥接客户端。

Odoo 20 Enterprise 随 AI app 内置 /mcp 端点（Streamable HTTP）。
本模块用标准库 urllib 实现一个最小 MCP HTTP 客户端，把官方暴露的工具
透传进 WorkBuddy。认证用带 MCP scope 的 API Key（Bearer）。

支持：
  - 响应为 application/json 或 text/event-stream（SSE）
  - Mcp-Session-Id 会话保持
  - initialize -> notifications/initialized 握手
"""

from __future__ import annotations

import json
import re
import ssl
import urllib.error
import urllib.request
from typing import Any
from urllib.parse import urlparse

from .config import Config
from .odoo_client import OdooError


class BridgeError(OdooError):
    def __init__(self, message: str, detail: Any = None):
        super().__init__(message, kind="bridge", detail=detail)


class OdooOfficialMCPClient:
    def __init__(self, config: Config):
        self.config = config
        self.endpoint = (config.mcp_url or config.url.rstrip("/") + "/mcp").strip()
        self.token = config.mcp_token or config.credential
        self.session_id: str | None = None
        self.protocol_version = "2025-06-18"
        self._id = 0
        self._initialized = False
        self._remote_tools: list[dict] | None = None

    def _next_id(self) -> int:
        self._id += 1
        return self._id

    # ---------- HTTP ----------

    def _parse_body(self, body: str, content_type: str) -> dict | None:
        if not body.strip():
            return None
        if "text/event-stream" in content_type or "data:" in body:
            messages: list[dict] = []
            for block in re.split(r"\r?\n\r?\n", body):
                for line in block.splitlines():
                    if line.startswith("data:"):
                        raw = line[5:].strip()
                        if raw and raw != "[DONE]":
                            try:
                                messages.append(json.loads(raw))
                            except json.JSONDecodeError:
                                continue
            return messages[-1] if messages else None
        return json.loads(body)

    def _post(self, payload: dict, expect_response: bool = True) -> dict | None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id

        ctx = None
        if urlparse(self.endpoint).scheme == "https" and not self.config.verify_ssl:
            ctx = ssl._create_unverified_context()

        req = urllib.request.Request(
            self.endpoint, data=data, headers=headers, method="POST"
        )
        try:
            with urllib.request.urlopen(
                req, timeout=self.config.timeout, context=ctx
            ) as resp:
                sid = resp.headers.get("Mcp-Session-Id")
                if sid:
                    self.session_id = sid
                if not expect_response:
                    return None
                content_type = resp.headers.get("Content-Type", "")
                body = resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise BridgeError(
                f"官方 MCP 返回 HTTP {exc.code}：{detail[:600]}", detail=detail
            ) from exc
        except (OSError, TimeoutError) as exc:
            raise BridgeError(
                f"无法连接官方 MCP 端点 {self.endpoint}：{exc}", detail=str(exc)
            ) from exc

        try:
            return self._parse_body(body, content_type)
        except json.JSONDecodeError as exc:
            raise BridgeError(
                f"官方 MCP 返回内容无法解析：{body[:400]}", detail=body[:1000]
            ) from exc

    def _request(self, method: str, params: dict | None = None) -> dict:
        payload = {
            "jsonrpc": "2.0",
            "id": self._next_id(),
            "method": method,
        }
        if params is not None:
            payload["params"] = params
        response = self._post(payload)
        if response is None:
            raise BridgeError(f"官方 MCP 对 {method} 无响应")
        if "error" in response:
            err = response["error"]
            raise BridgeError(
                f"官方 MCP {method} 错误：{err.get('message')}",
                detail=err,
            )
        return dict(response.get("result") or {})

    def _notify(self, method: str, params: dict | None = None) -> None:
        payload: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        self._post(payload, expect_response=False)

    # ---------- MCP 方法 ----------

    def initialize(self) -> dict:
        if self._initialized:
            return {"session_id": self.session_id}
        if not self.token:
            raise BridgeError(
                "桥接模式需要 Bearer Token：请设置 ODOO_MCP_TOKEN"
                "（在 Odoo 用户偏好 → Security 生成 scope=MCP 的 API Key）"
            )
        result = self._request("initialize", {
            "protocolVersion": self.protocol_version,
            "capabilities": {},
            "clientInfo": {"name": "workbuddy-odoo-connector", "version": "1.0.0"},
        })
        version = result.get("protocolVersion")
        if version:
            self.protocol_version = version
        self._notify("notifications/initialized", {})
        self._initialized = True
        return {
            "session_id": self.session_id,
            "protocol_version": self.protocol_version,
            "server_info": result.get("serverInfo"),
            "capabilities": result.get("capabilities"),
        }

    def list_tools(self, refresh: bool = False) -> list[dict]:
        if self._remote_tools is not None and not refresh:
            return self._remote_tools
        self.initialize()
        result = self._request("tools/list", {})
        tools = result.get("tools") or []
        # 规范化：确保每个工具有合法 inputSchema
        normalized: list[dict] = []
        for tool in tools:
            if not isinstance(tool, dict) or not tool.get("name"):
                continue
            schema = tool.get("inputSchema")
            if not isinstance(schema, dict):
                schema = {"type": "object", "properties": {}}
            normalized.append({
                "name": tool["name"],
                "description": tool.get("description") or "Odoo 官方 MCP 工具",
                "inputSchema": schema,
            })
        self._remote_tools = normalized
        return normalized

    def call_tool(self, name: str, arguments: dict | None) -> tuple[str, bool]:
        self.initialize()
        result = self._request("tools/call", {
            "name": name,
            "arguments": arguments or {},
        })
        content = result.get("content") or []
        parts: list[str] = []
        for item in content:
            if not isinstance(item, dict):
                parts.append(str(item))
                continue
            ctype = item.get("type")
            if ctype == "text":
                parts.append(str(item.get("text") or ""))
            elif ctype == "resource":
                resource = item.get("resource") or {}
                parts.append(
                    f"[resource {resource.get('uri', '')}] "
                    f"{str(resource.get('text') or '')[:2000]}"
                )
            else:
                parts.append(str(item.get("data") or item))
        text = "\n".join(parts) if parts else json.dumps(result, ensure_ascii=False)
        return text, bool(result.get("isError"))

    def status(self) -> dict:
        info: dict[str, Any] = {
            "mode": "bridge",
            "endpoint": self.endpoint,
            "initialized": self._initialized,
            "session_id": self.session_id,
            "protocol_version": self.protocol_version,
            "auth": "bearer" if self.token else "none",
            "token_source": (
                "ODOO_MCP_TOKEN" if self.config.mcp_token else "ODOO_API_KEY/PASSWORD"
            ),
        }
        try:
            info["remote_tool_count"] = len(self.list_tools())
        except BridgeError as exc:
            info["error"] = exc.message
        return info
