"""odoo-connector server package（零第三方依赖）。"""
