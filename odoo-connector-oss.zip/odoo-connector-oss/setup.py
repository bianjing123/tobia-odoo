#!/usr/bin/env python3
"""Odoo Connector 一键安装向导 —— 安装 + 配置 + 验证，一个脚本搞定。

双击 setup.bat（Windows）或运行 python setup.py，会依次：
  1. 问答收集连接参数（密码 / API Key 隐藏输入）
  2. 当场连接验证，成功才继续
  3. 复制插件到 WorkBuddy 安装目录
  4. 把配置写到安装目录（server 实际读取的位置 —— 关键：填了就生效）
  5. 注册 MCP 到 ~/.workbuddy/mcp.json，并清空会覆盖配置的 env 值
  6. 安装配套 Skill 到用户级目录
  7. 提示重启 WorkBuddy

其它用法：
  python setup.py --check                 查看当前生效配置（脱敏）
  python setup.py --non-interactive ...   由脚本 / AI 代填参数
  python setup.py --install-only          跳过配置，只做安装（升级插件用）

安全：密钥从不回显、从不写日志；--check 只显示脱敏信息。零第三方依赖。
"""

from __future__ import annotations

import argparse
import getpass
import json
import shutil
import sys
from pathlib import Path

SRC_ROOT = Path(__file__).resolve().parent
HOME = Path.home()
WB = HOME / ".workbuddy"
MARKET_ROOT = WB / "plugins" / "marketplaces" / "odoo-connector-local"
PLUGIN_DEST = MARKET_ROOT / "plugins" / "odoo-connector"
MCP_JSON = WB / "mcp.json"
SKILL_SRC = SRC_ROOT / "skills" / "odoo-connector"
SKILL_DEST = WB / "skills" / "odoo-connector"
CONFIG_FILE = PLUGIN_DEST / "config" / "odoo.config.json"  # 安装目录（生效位置）

# 让 import server.* 生效（用源目录的代码做验证）
sys.path.insert(0, str(SRC_ROOT))
from server.config import DEFAULTS, Config  # noqa: E402
from server.odoo_client import OdooClient, OdooError  # noqa: E402

try:
    from server.bridge import OdooOfficialMCPClient  # noqa: E402
except ImportError:  # pragma: no cover
    OdooOfficialMCPClient = None  # type: ignore

# mcp.json 里这些 env 一旦有值会覆盖配置文件，安装时统一清空
OVERRIDE_ENV_KEYS = (
    "ODOO_MODE", "ODOO_URL", "ODOO_DB", "ODOO_USER", "ODOO_API_KEY",
    "ODOO_PASSWORD", "ODOO_MCP_URL", "ODOO_MCP_TOKEN", "ODOO_VERSION",
    "ODOO_TIMEOUT", "ODOO_CONFIG_FILE",
)
EMPTY_ENV = {k: "" for k in OVERRIDE_ENV_KEYS}


# ----------------------------- 通用小工具 -----------------------------

def _ask(prompt: str, default: str = "", *, secret: bool = False) -> str:
    suffix = f" [{default}]" if default and not secret else ""
    if secret:
        value = getpass.getpass(f"{prompt}{suffix}: ")
    else:
        try:
            value = input(f"{prompt}{suffix}: ")
        except EOFError:
            return default
    return value.strip() or default


def _mask(value: str) -> str:
    if not value:
        return "(未设置)"
    if len(value) <= 4:
        return "*" * len(value)
    return f"{value[:2]}{'*' * (len(value) - 4)}{value[-2:]}"


def _title(text: str) -> None:
    print()
    print("=" * 56)
    print(f"  {text}")
    print("=" * 56)


# ----------------------------- 配置收集与验证 -----------------------------

def _verify(values: dict) -> tuple[bool, str]:
    """真实连接验证。返回 (成功与否, 说明)。不打印凭据。"""
    cfg = Config(values)
    problems = cfg.validate()
    if problems:
        return False, "配置不完整：" + "；".join(problems)

    if cfg.mode == "bridge":
        if OdooOfficialMCPClient is None:
            return False, "bridge 客户端不可用"
        try:
            client = OdooOfficialMCPClient(cfg)
            info = client.initialize()
            tools = client.list_tools(refresh=True)
            return True, (
                f"官方 MCP 连接成功（{info.get('server_info', {}).get('name', 'Odoo')}），"
                f"暴露 {len(tools)} 个工具"
            )
        except Exception as exc:  # noqa: BLE001
            return False, f"官方 MCP 连接失败：{type(exc).__name__}: {exc}"

    try:
        client = OdooClient(cfg)
        ver = client.version()
        uid = client.authenticate()
        server_ver = (
            ver.get("server_version")
            or ver.get("version")
            or ver.get("version_info", {}).get("version", "?")
        )
        return True, f"连接成功：Odoo {server_ver}，认证 uid={uid}（{cfg.auth_mode}）"
    except OdooError as exc:
        return False, str(exc)
    except Exception as exc:  # noqa: BLE001
        return False, f"连接失败：{type(exc).__name__}: {exc}"


def _summary(values: dict) -> None:
    print()
    print("配置摘要（凭据已隐藏）：")
    mode = values.get("mode", "native")
    print(f"  模式      : {mode}")
    if mode == "bridge":
        print(f"  MCP 端点  : {values.get('mcp_url') or (values.get('url', '') + '/mcp')}")
        print(f"  Token     : {_mask(values.get('mcp_token', ''))}")
    else:
        print(f"  地址      : {values.get('url')}")
        print(f"  数据库    : {values.get('db')}")
        print(f"  账号      : {values.get('user')}")
        print(f"  认证方式  : {'API Key' if values.get('api_key') else '密码'}")
        print(f"  凭据      : {_mask(values.get('api_key') or values.get('password', ''))}")
        print(f"  版本      : {values.get('version', DEFAULTS['version'])}")


def interactive() -> dict:
    _title("Odoo Connector 一键安装向导")
    print("填完会当场验证连接，成功后再安装。密钥输入时不会显示。")
    print("随时 Ctrl+C 退出，不会写入半成品。")

    print()
    print("选择连接模式：")
    print("  1) native  — 自研 XML-RPC，支持 Odoo 14-20 / Community（推荐）")
    print("  2) bridge  — 透传 Odoo 20 Enterprise 官方 /mcp")
    mode = "bridge" if _ask("请输入 1 或 2", "1").strip() == "2" else "native"
    values: dict = {"mode": mode}

    if mode == "bridge":
        print()
        print("--- Odoo 20 官方 MCP 参数 ---")
        values["url"] = _ask("Odoo 站点地址", "https://erp.example.com")
        values["mcp_url"] = _ask("官方 MCP 端点（留空自动用 地址/mcp）", "")
        values["mcp_token"] = _ask("API Key（scope=MCP，输入不显示）", secret=True)
    else:
        print()
        print("--- Odoo 连接参数 ---")
        values["url"] = _ask("Odoo 地址（含 http/https）", "https://erp.example.com")
        values["db"] = _ask("数据库名", "")
        values["user"] = _ask("登录账号（邮箱）", "")
        auth = _ask("认证方式：1=API Key（推荐） 2=密码", "1")
        if auth.strip() == "2":
            values["password"] = _ask("登录密码（输入不显示）", secret=True)
        else:
            values["api_key"] = _ask("API Key（输入不显示）", secret=True)
        values["version"] = _ask("Odoo 版本", DEFAULTS["version"])

    values["verify_ssl"] = _ask("验证 SSL 证书？y/n", "y").lower() in ("y", "yes", "")
    return values


def non_interactive(args: argparse.Namespace) -> dict:
    mode = args.mode or "native"
    values: dict = {"mode": mode}
    if mode == "bridge":
        values["url"] = args.url or DEFAULTS["url"]
        values["mcp_url"] = args.mcp_url or ""
        values["mcp_token"] = args.mcp_token or ""
    else:
        values["url"] = args.url or ""
        values["db"] = args.db or ""
        values["user"] = args.user or ""
        if args.api_key:
            values["api_key"] = args.api_key
        if args.password:
            values["password"] = args.password
        values["version"] = args.version or DEFAULTS["version"]
    values["verify_ssl"] = not args.no_verify_ssl
    if args.timeout:
        values["timeout"] = args.timeout
    return values


# ----------------------------- 安装动作 -----------------------------

def _write_config(values: dict) -> None:
    """把有效配置写到【安装目录】—— server 实际读取的位置。"""
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    ordered = {
        "_说明": "由 setup.py 生成。重跑向导即可修改，无需手改本文件。",
        "mode": values.get("mode", "native"),
    }
    if values.get("mode", "native") == "bridge":
        ordered["mcp_url"] = values.get("mcp_url", "")
        ordered["mcp_token"] = values.get("mcp_token", "")
        ordered["url"] = values.get("url", DEFAULTS["url"])
    else:
        ordered["url"] = values.get("url", "")
        ordered["db"] = values.get("db", "")
        ordered["user"] = values.get("user", "")
        if values.get("api_key"):
            ordered["api_key"] = values["api_key"]
        if values.get("password"):
            ordered["password"] = values["password"]
        ordered["version"] = values.get("version", DEFAULTS["version"])
    ordered["verify_ssl"] = values.get("verify_ssl", True)
    if values.get("timeout"):
        ordered["timeout"] = values["timeout"]

    CONFIG_FILE.write_text(
        json.dumps(ordered, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    try:
        CONFIG_FILE.chmod(0o600)
    except OSError:
        pass


def copy_plugin() -> None:
    MARKET_ROOT.mkdir(parents=True, exist_ok=True)
    if PLUGIN_DEST.exists():
        shutil.rmtree(PLUGIN_DEST)
    shutil.copytree(
        SRC_ROOT,
        PLUGIN_DEST,
        ignore=shutil.ignore_patterns(
            "__pycache__", "*.pyc", "output", "*.config.json", ".git"
        ),
    )
    # 复制后，配置由 _write_config 单独写入安装目录
    marketplace = {
        "name": "odoo-connector-local",
        "description": "本地 Odoo 连接器插件市场（native + bridge 双模式）",
        "owner": {"name": "边境 / 沈阳欧度科技"},
        "plugins": [
            {
                "name": "odoo-connector",
                "source": "./plugins/odoo-connector",
                "version": "1.2.0",
                "description": "Odoo 连接器：XML-RPC 全版本 + Odoo 20 官方 MCP 桥接",
            }
        ],
    }
    (MARKET_ROOT / ".codebuddy-plugin").mkdir(parents=True, exist_ok=True)
    (MARKET_ROOT / ".codebuddy-plugin" / "marketplace.json").write_text(
        json.dumps(marketplace, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("  [1/4] 插件已安装到：" + str(PLUGIN_DEST))


def register_mcp() -> None:
    """注册 MCP；清空 env 连接键，让配置文件成为唯一真相源。"""
    MCP_JSON.parent.mkdir(parents=True, exist_ok=True)
    data: dict = {"mcpServers": {}}
    if MCP_JSON.exists():
        try:
            data = json.loads(MCP_JSON.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            backup = MCP_JSON.with_suffix(".json.bak")
            shutil.copy2(MCP_JSON, backup)
            print("      原 mcp.json 解析失败，已备份到 " + str(backup))
            data = {"mcpServers": {}}

    servers = data.setdefault("mcpServers", {})
    target = None
    for name, srv in servers.items():
        if isinstance(srv, dict) and any(
            "odoo_mcp_server.py" in str(a) for a in srv.get("args", [])
        ):
            target = (name, srv)
            break

    if target:
        name, srv = target
        # 修正入口路径（防旧版指向别处），并清空会覆盖配置的 env
        srv["args"] = [str((PLUGIN_DEST / "odoo_mcp_server.py").resolve())]
        srv["env"] = dict(EMPTY_ENV)
        print(f"  [2/4] 已更新 MCP「{name}」，并清空 env（配置改为文件生效）")
    else:
        servers["odoo-connector"] = {
            "command": "python",
            "args": [str((PLUGIN_DEST / "odoo_mcp_server.py").resolve())],
            "env": dict(EMPTY_ENV),
        }
        print("  [2/4] MCP 已注册到：" + str(MCP_JSON))

    MCP_JSON.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def install_skill() -> None:
    if not SKILL_SRC.exists():
        print("  [3/4] 跳过：源 skill 不存在 " + str(SKILL_SRC))
        return
    SKILL_DEST.parent.mkdir(parents=True, exist_ok=True)
    src_file = SKILL_SRC / "SKILL.md"
    dst_file = SKILL_DEST / "SKILL.md"
    if dst_file.exists() and dst_file.read_bytes() == src_file.read_bytes():
        print("  [3/4] Skill 已是最新")
        return
    if SKILL_DEST.exists():
        shutil.rmtree(SKILL_DEST)
    shutil.copytree(SKILL_SRC, SKILL_DEST)
    print("  [3/4] Skill 已安装到用户级目录")


def do_install() -> None:
    print()
    print("开始安装（幂等，可重复运行）：")
    copy_plugin()
    register_mcp()
    install_skill()
    print("  [4/4] 完成")


# ----------------------------- 命令入口 -----------------------------

def do_check() -> int:
    _title("当前生效配置")
    path = CONFIG_FILE if CONFIG_FILE.exists() else (
        SRC_ROOT / "config" / "odoo.config.json"
    )
    if not path.exists():
        print("尚未配置。运行 setup.py（或双击 setup.bat）开始。")
        return 1
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"配置文件格式错误：{exc}")
        return 1
    cfg = Config(data)
    problems = cfg.validate()
    print(f"  配置文件  : {path}")
    print(f"  模式      : {cfg.mode}")
    if cfg.mode == "bridge":
        print(f"  MCP 端点  : {cfg.mcp_url or cfg.url + '/mcp'}")
        print(f"  Token     : {_mask(cfg.mcp_token)}")
    else:
        print(f"  地址      : {cfg.url}")
        print(f"  数据库    : {cfg.db or '(未设置)'}")
        print(f"  账号      : {cfg.user or '(未设置)'}")
        print(f"  认证方式  : {cfg.auth_mode}")
        print(f"  凭据      : {_mask(cfg.credential)}")
    print(f"  配置校验  : {'通过' if not problems else '；'.join(problems)}")
    return 0 if not problems else 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Odoo Connector 一键安装向导（安装 + 配置 + 验证）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例：\n"
            "  python setup.py\n"
            "  python setup.py --check\n"
            "  python setup.py --non-interactive --url https://erp.example.com "
            "--db mydb --user admin --api-key KEY --verify\n"
        ),
    )
    p.add_argument("--check", action="store_true", help="查看当前生效配置（脱敏）")
    p.add_argument("--non-interactive", action="store_true", help="非交互模式，由脚本代填")
    p.add_argument("--install-only", action="store_true", help="跳过配置，只安装/升级插件")
    p.add_argument("--mode", choices=["native", "bridge"], help="连接模式")
    p.add_argument("--url", help="Odoo 地址")
    p.add_argument("--db", help="数据库名")
    p.add_argument("--user", help="登录账号")
    p.add_argument("--api-key", dest="api_key", help="API Key")
    p.add_argument("--password", help="登录密码")
    p.add_argument("--mcp-url", dest="mcp_url", help="bridge 官方 MCP 端点")
    p.add_argument("--mcp-token", dest="mcp_token", help="bridge Bearer Token")
    p.add_argument("--version", help="Odoo 版本")
    p.add_argument("--timeout", type=int, help="超时秒数")
    p.add_argument("--no-verify-ssl", action="store_true", help="关闭 SSL 校验")
    p.add_argument("--skip-test", action="store_true", help="跳过连接验证")
    p.add_argument("--verify", action="store_true", help="非交互模式下也验证连接")
    return p


def main() -> int:
    args = build_parser().parse_args()

    if args.check:
        return do_check()

    if args.install_only:
        do_install()
        print()
        print("升级完成。配置未改动，重启 WorkBuddy 生效。")
        return 0

    values = non_interactive(args) if args.non_interactive else interactive()
    _summary(values)

    should_test = (not args.non_interactive and not args.skip_test) or (
        args.non_interactive and args.verify and not args.skip_test
    )
    if should_test:
        print()
        print("正在验证连接（最多约 30 秒）...")
        ok, msg = _verify(values)
        print(("  ✓ " if ok else "  ✗ ") + msg)
        if not ok:
            print()
            if _ask("连接失败，仍要继续安装吗？y/n", "n").lower() not in ("y", "yes"):
                print("已取消，未安装、未写入任何配置。")
                return 1
    else:
        print()
        print("（已跳过连接验证）")

    do_install()
    _write_config(values)
    print(f"  ✓ 配置已写入：{CONFIG_FILE}")

    print()
    print("=" * 56)
    print("  全部完成！请重启 WorkBuddy 让它加载插件。")
    print("  验证：对话里说『用 odoo_ping 检查 Odoo 连接』")
    print("=" * 56)
    return 0


if __name__ == "__main__":
    sys.exit(main())
